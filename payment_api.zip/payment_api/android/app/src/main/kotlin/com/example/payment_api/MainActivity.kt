package com.example.payment_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
